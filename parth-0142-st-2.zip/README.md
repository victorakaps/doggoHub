hosted at: https://parthsethi.in/doggoHub
